## intent:affirm
- uh yes im looking for approval workflow
- correct
- ye
- let's do it
- yeah
- um yes
- right
- yea
- yes
- yes right
- yeah i need to find case with ID
- uh yes i want to open case management
- uh yes
- right on good bye
- yes Trade Account

## intent:deny
- no not wires
- no close this one
- no
- no new selection
- no im looking for updated cases
- no thanks
- no i want latest updates
- no thank you good bye
- no thank you
- no this does not work for me

## intent:greet
- hi there
- hello there
- hey
- hi
- hey bot
- good morning
- goodmorning
- hello
- goodevening
- goodafternoon
- good evening
- morning
- good afternoon

## intent:inform
- i want to open [trade](accounttype) account.
- i want to open [trust](accounttype) account.

## intent:request_info
- do you have RAG [service](info)
- do you have RAG [phone number](info)

## intent:thankyou
- um thank you good bye
- okay cool uh good bye thank you
- okay thank you good bye
- you rock
- and thats all thank you and good bye
- thank you and good bye
- sorry about my mistakes thank you good bye
- noise thank you good bye
- thank you goodbye noise
- okay thank you goodbye
- uh thank you good bye
- thank you goodbye
- thank you goodbye noise thank you goodbye
- breath thank you goodbye
- thank you
- okay thank you
- thanks goodbye
- ah thank you goodbye
- thank you noise
- thank you good bye
- breath thank you very much goodbye
- thanks
- noise thank you goodbye
- unintelligible thank you goodbye
- uh okay thank you good bye
- thank you bye
- um okay thank you good bye