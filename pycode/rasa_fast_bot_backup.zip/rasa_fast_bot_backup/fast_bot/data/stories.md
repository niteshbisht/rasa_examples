## story_00914561
* greet
 - utter_ask_howcanhelp
* inform{"account": "Trade"}
 - utter_on_it
 - utter_ask_queue
* inform{"queue": "Advisory"}
 - utter_ask_product_type
* inform{"prodtype": "Equity"}
 - utter_ask_adjustmenttype
* inform{"adjtype":"Account Type Change"}
 - utter_ask_readytostartworkflow
* affirm
 - utter_ack_starting_workflow
  
## story_00914562
* greet
 - utter_ask_howcanhelp
* inform{"account": "Trade"}
 - utter_on_it
 - utter_ask_queue
* inform{"queue": "Branch"}
 - utter_ask_product_type
* inform{"prodtype": "mutual"}
 - utter_ask_adjustmenttype
* inform{"adjtype":"Account Number Change"}
 - utter_ask_readytostartworkflow
* affirm
 - utter_ack_starting_workflow
 
 
## story_00914562
* greet
 - utter_ask_howcanhelp
* inform{"account": "Trade"}
 - utter_on_it
 - utter_ask_queue
* deny
 - action_search_queue
 - action_suggest  
* inform{"prodtype": "mutual"}
 - utter_ask_adjustmenttype
* inform{"adjtype":"Account Number Change"}
 - utter_ask_readytostartworkflow
* affirm
 - utter_ack_starting_workflow
 
 
## story_00914562
* greet
 - utter_ask_howcanhelp
* inform{"probaccount": "new"}
 - utter_missing_account_type
 - action_search_accounttypes
 - action_suggest
* affirm
 - slot{"account":"trade"}
 - utter_ask_adjustmenttype
* inform{"adjtype":"Account Number Change"}
 - utter_ask_readytostartworkflow
* affirm
 - utter_ack_starting_workflow
  
