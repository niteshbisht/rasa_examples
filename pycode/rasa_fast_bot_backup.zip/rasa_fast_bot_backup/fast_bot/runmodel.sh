#!/bin/bash
python -m rasa_core.run -d models/dialogue -u models/current/nlu