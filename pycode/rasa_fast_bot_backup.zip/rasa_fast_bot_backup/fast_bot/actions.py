from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet
from rest_bot import AccountSearchAPI, AccountTypeSearchAPI
import logging

logger = logging.getLogger(__name__)


class ActionSearchAccountType(Action):
    def name(self):
        return 'action_search_accounttypes'

    def run(self,dispatcher, tracker, domain):
        dispatcher.utter_message("looking for Account types")
        accountTypeSearchAPI = AccountTypeSearchAPI()
        probaccount = tracker.get_slot("probaccount")
        logger.debug("probaccount = {}",probaccount)
        accountType = accountTypeSearchAPI.search(probaccount)
        return [SlotSet("matches", accountType)]

class ActionSearchAccounts(Action):
    def name(self):
        return 'action_search_queue'

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("looking for queue")
        queueSearch_api = AccountSearchAPI()
        queueTypes = queueSearch_api.search(tracker.get_slot("account"))
        return [SlotSet("matches", queueTypes)]


class ActionSuggest(Action):
    def name(self):
        return 'action_suggest'

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("here's what I found:")
        dispatcher.utter_message(tracker.get_slot("matches"))
        dispatcher.utter_message("is it ok for you? "
                                 "hint: I'm not going to "
                                 "find anything else :)")
        return []
